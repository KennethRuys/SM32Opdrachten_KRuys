//
//  Pirate.m
//  aGoodName
//
//  Created by FHICT on 19/03/14.
//  Copyright (c) 2014 FHICT. All rights reserved.
//

#import "Pirate.h"

@implementation Pirate

@synthesize name;
@synthesize life;
@synthesize active;
@synthesize countryOfOrigin;
@synthesize comments;



@end
