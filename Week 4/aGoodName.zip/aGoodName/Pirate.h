//
//  Pirate.h
//  aGoodName
//
//  Created by FHICT on 19/03/14.
//  Copyright (c) 2014 FHICT. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Pirate : NSObject

@property NSString *name;
@property NSString *life;
@property NSString *active;
@property NSString *countryOfOrigin;
@property NSString *comments;

@end
