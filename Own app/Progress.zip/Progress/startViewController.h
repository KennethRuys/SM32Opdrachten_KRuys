//
//  startViewController.h
//  Progress
//
//  Created by FHICT on 20/03/14.
//  Copyright (c) 2014 FHICT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface startViewController : UIViewController
- (IBAction)LoginButton:(UIButton *)sender;
- (IBAction)RegisterButton:(UIButton *)sender;
- (IBAction)FBLoginButton:(UIButton *)sender;

@end
