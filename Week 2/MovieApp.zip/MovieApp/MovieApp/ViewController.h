//
//  ViewController.h
//  MovieApp
//
//  Created by FHICT on 12/03/14.
//  Copyright (c) 2014 FHICT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
